"""HTTP route factory for the first standalone AD service operation."""

from __future__ import annotations

import base64
import binascii
import logging
import re
from dataclasses import dataclass
from collections.abc import Callable
from urllib.parse import urlencode
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .machine_registry import MachineRegistry
    from .machine_auth import ReplayGuard
    from .directory import ActiveDirectory
    from .challenges import ChallengeStore
    from .phone_registry import PhoneRegistry
    from .ad_logon_keys import AdLogonKeyRegistry
    from .piv_signatures import PivSignatureStore


MACHINE_ENROLL_PATH = "/thessley-ad/v1/machines/enroll"
MACHINE_AUTH_PATH = "/thessley-ad/v1/machines/authenticate"
DIRECTORY_USERS_PATH = "/thessley-ad/v1/directory/users"
PHONE_KEYS_PATH = "/thessley-ad/v1/directory/phone-keys"
PHONE_KEY_REVOKE_PATH = "/thessley-ad/v1/directory/phone-keys/revoke"
PRINCIPAL_RESOLVE_PATH = "/thessley-ad/v1/principals/resolve"
PRINCIPAL_RESOLVE_NAME_PATH = "/thessley-ad/v1/principals/resolve-name"
LOGIN_START_PATH = "/thessley-ad/v1/requests"
PHONE_RESPONSE_PATH = "/thessley-ad/v1/requests/respond"
LOGIN_RESULT_PATH = "/thessley-ad/v1/requests/result"
CERTIFICATE_CSR_SUBMIT_PATH = "/thessley-ad/v1/requests/certificate_csr"
CERTIFICATE_RESULT_PATH = "/thessley-ad/v1/requests/certificate_result"
PHONE_ENROLL_START_PATH = "/thessley-ad/v1/enrollments"
PHONE_ENROLL_RESPONSE_PATH = "/thessley-ad/v1/enrollments/respond"
PHONE_ENROLL_STATUS_PATH = "/thessley-ad/v1/enrollments/status"
PHONE_ENROLL_CONFIRM_PATH = "/thessley-ad/v1/enrollments/confirm"
PHONE_ENROLL_CANCEL_PATH = "/thessley-ad/v1/enrollments/cancel"
AD_LOGON_KEY_ENROLL_PATH = "/thessley-ad/v1/logon-keys/enroll"
AD_LOGON_KEY_STATUS_PATH = "/thessley-ad/v1/logon-keys/status"
PIV_SIGN_START_PATH = "/thessley-ad/v1/piv-sign/start"
PIV_SIGN_RESULT_PATH = "/thessley-ad/v1/piv-sign/result"
PIV_SIGN_PHONE_PENDING_PATH = "/thessley-ad/v1/piv-sign/phone-pending"
PIV_SIGN_PHONE_RESPONSE_PATH = "/thessley-ad/v1/piv-sign/phone-response"
_HEX_SHA256 = re.compile(r"^[a-f0-9]{64}$")
_B64_PIV_INPUT = re.compile(r"^[A-Za-z0-9+/]{40,120}={0,2}$")


@dataclass(frozen=True)
class RawBodyRoute:
    """Transport-neutral route that verifies signatures over exact HTTP bytes."""

    handler: Callable[[str, dict, bytes, dict[str, str]], tuple[int, dict]]
    response_wait: int = 15

    def __post_init__(self) -> None:
        if (isinstance(self.response_wait, bool) or not isinstance(self.response_wait, int)
                or not 1 <= self.response_wait <= 125):
            raise ValueError("Raw route response wait must be between 1 and 125 seconds.")


def _authenticated_machine(machine_id: str, timestamp_text: str, nonce: str, signature: str,
                           path: str, raw_body: bytes, registry: "MachineRegistry",
                           replay_guard: "ReplayGuard") -> bool:
    from .machine_auth import verify_request

    try:
        timestamp = int(timestamp_text)
    except (TypeError, ValueError):
        return False
    public_key = registry.public_key(machine_id)
    return bool(public_key) and verify_request(
        public_key_spki_b64=public_key,
        signature_b64=signature,
        method="POST",
        path=path,
        machine_id=machine_id,
        timestamp=timestamp,
        nonce=nonce,
        body=raw_body,
        replay_guard=replay_guard,
    )


def machine_enrollment_route(registry: "MachineRegistry"):
    """Return a raw-body listener route for one-time machine enrollment.

    Enrollment is authorized by the short-lived, single-use code. The code
    itself must have been created by an admin-authorized local caller. The
    machine display name is metadata only and grants no AD rights.
    """
    def handle(_client_ip: str, body: dict, _raw_body: bytes, auth_headers: dict[str, str]):
        if auth_headers:
            return 400, {"result": "error", "message": "Do not send machine-auth headers to enrollment."}
        if set(body) != {"code", "machine_name", "public_key_spki_b64"}:
            return 400, {"result": "error", "message": "Invalid enrollment request."}
        try:
            machine_id = registry.enroll(
                code=body["code"],
                machine_name=body["machine_name"],
                public_key_spki_b64=body["public_key_spki_b64"],
            )
        except (TypeError, ValueError):
            machine_id = None
        if machine_id is None:
            return 403, {"result": "error", "message": "Enrollment code is invalid or expired."}
        return 201, {"result": "enrolled", "machine_id": machine_id}

    return RawBodyRoute(handle)


def machine_authentication_route(registry: "MachineRegistry", replay_guard: "ReplayGuard"):
    """Return an authenticated machine liveness endpoint for protocol bring-up."""
    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        if set(auth_headers) != expected or body != {}:
            return 400, {"result": "error", "message": "Invalid machine authentication request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], MACHINE_AUTH_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        return 200, {"result": "authenticated", "machine_id": machine_id}

    return RawBodyRoute(handle)


def directory_users_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                          directory: "ActiveDirectory", allowed_group_sids: frozenset[str]):
    """Return a bounded directory view only to an enrolled, signed workstation."""
    from .directory import DirectoryUnavailable

    allowed_group_sids = frozenset(allowed_group_sids)

    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        if set(auth_headers) != expected or body != {}:
            return 400, {"result": "error", "message": "Invalid directory request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], DIRECTORY_USERS_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        list_users = getattr(directory, "list_users", None)
        if not callable(list_users):
            return 503, {"result": "error", "message": "The AD directory listing is unavailable on this service."}
        try:
            snapshot = list_users(allowed_group_sids)
        except DirectoryUnavailable:
            return 503, {"result": "error", "message": "The AD directory is temporarily unavailable."}
        if (not isinstance(snapshot, dict) or not isinstance(snapshot.get("domain"), str)
                or not snapshot["domain"] or len(snapshot["domain"]) > 256
                or not isinstance(snapshot.get("users"), list) or len(snapshot["users"]) > 1000
                or not isinstance(snapshot.get("truncated"), bool)):
            return 503, {"result": "error", "message": "The AD directory returned an invalid response."}
        for user in snapshot["users"]:
            if (not isinstance(user, dict)
                    or not isinstance(user.get("sam"), str) or not user["sam"] or len(user["sam"]) > 64
                    or not isinstance(user.get("sid"), str) or not re.fullmatch(r"S-1-(?:[0-9]+-)+[0-9]+", user["sid"])
                    or not isinstance(user.get("name"), str) or len(user["name"]) > 256
                    or not isinstance(user.get("upn"), str) or len(user["upn"]) > 256
                    or not isinstance(user.get("enabled"), bool)
                    or not isinstance(user.get("authorized"), bool)):
                return 503, {"result": "error", "message": "The AD directory returned an invalid response."}
        return 200, {"result": "listed", **snapshot}

    return RawBodyRoute(handle)


def phone_keys_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                     phones: "PhoneRegistry"):
    """List machine keys, or active keys for one principal usable on the authenticated machine."""
    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {"x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"}
        principal_id = body.get("principal_id")
        if (set(auth_headers) != expected
                or (body != {} and (set(body) != {"principal_id"}
                                    or not isinstance(principal_id, str)
                                    or not _HEX_SHA256.fullmatch(principal_id)))):
            return 400, {"result": "error", "message": "Invalid phone-key listing request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(machine_id, auth_headers["x-thessley-timestamp"],
                                      auth_headers["x-thessley-nonce"], auth_headers["x-thessley-signature"],
                                      PHONE_KEYS_PATH, raw_body, registry, replay_guard):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        if not registry.machine_name(machine_id):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        keys = (phones.list_for_machine(machine_id) if principal_id is None
                else phones.list_for_principal_on_machine(principal_id, machine_id))
        if len(keys) > 5000:
            return 503, {"result": "error", "message": "The phone-key listing is too large."}
        return 200, {"result": "listed", "keys": keys}
    return RawBodyRoute(handle)


def phone_key_revoke_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                           phones: "PhoneRegistry"):
    """Revoke a key only when it belongs to the authenticated machine."""
    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {"x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"}
        credential_id = body.get("credential_id")
        if (set(auth_headers) != expected or set(body) != {"credential_id"}
                or not isinstance(credential_id, str)
                or not re.fullmatch(r"[A-Za-z0-9_-]{32,64}", credential_id)):
            return 400, {"result": "error", "message": "Invalid phone-key revocation request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(machine_id, auth_headers["x-thessley-timestamp"],
                                      auth_headers["x-thessley-nonce"], auth_headers["x-thessley-signature"],
                                      PHONE_KEY_REVOKE_PATH, raw_body, registry, replay_guard):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        if not registry.machine_name(machine_id):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        if not phones.revoke_for_machine(credential_id, machine_id):
            return 404, {"result": "error", "message": "No active matching phone key was found for this computer."}
        return 200, {"result": "revoked"}
    return RawBodyRoute(handle)


def principal_resolve_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                            directory: "ActiveDirectory", allowed_group_sids: frozenset[str], login_policy=None):
    """Resolve a signed SID request using AD as the sole group authority."""
    from .directory import DirectoryUnavailable, PrincipalNotFound, validate_group_sid_allowlist
    from .login_policy import PolicyError, METHOD_TPM

    allowed_group_sids = validate_group_sid_allowlist(allowed_group_sids)

    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        if set(auth_headers) != expected or set(body) != {"sid"} or not isinstance(body.get("sid"), str):
            return 400, {"result": "error", "message": "Invalid principal request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], PRINCIPAL_RESOLVE_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        try:
            principal = directory.resolve_user_sid(body["sid"])
        except PrincipalNotFound:
            return 404, {"result": "error", "message": "Domain user was not found or is disabled."}
        except DirectoryUnavailable:
            return 503, {"result": "error", "message": "Domain authorization is temporarily unavailable."}
        authorized = bool(principal.group_sids.intersection(allowed_group_sids))
        try:
            policy = login_policy.resolve(machine_id, principal.group_sids) if login_policy else {
                "method": METHOD_TPM, "source": "domain-default"
            }
        except PolicyError:
            return 503, {"result": "error", "message": "The workstation sign-in policy is unavailable."}
        return 200, {
            "result": "resolved",
            "credential_method": policy["method"],
            "policy_source": policy["source"],
            "principal": {
                "sid": principal.sid,
                "principal_id": principal.principal_id,
                "principal_type": "domain",
                "authority": principal.authority,
                "username": principal.username,
            },
            "authorized": authorized,
        }

    return RawBodyRoute(handle)


def principal_resolve_name_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                                 directory: "ActiveDirectory", allowed_group_sids: frozenset[str],
                                 login_policy=None):
    """Resolve a generic Other-user SAM name; AD remains the identity and group authority."""
    from .directory import DirectoryUnavailable, PrincipalNotFound, validate_group_sid_allowlist
    from .login_policy import PolicyError, METHOD_TPM

    allowed_group_sids = validate_group_sid_allowlist(allowed_group_sids)

    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        account = body.get("account")
        if (set(auth_headers) != expected or set(body) != {"account"}
                or not isinstance(account, str)
                or len(account) > 160):
            return 400, {"result": "error", "message": "Invalid domain-account request."}
        username = account
        if "\\" in account:
            domain, username = account.split("\\", 1)
            configured_authority = getattr(getattr(directory, "config", None), "authority", "")
            if not configured_authority or domain.casefold() != configured_authority.casefold():
                return 404, {"result": "error", "message": "This domain account is unavailable for sign-in."}
        if not re.fullmatch(r"[a-z_][a-z0-9_.-]{0,31}", username, re.IGNORECASE):
            return 400, {"result": "error", "message": "Invalid domain-account request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], PRINCIPAL_RESOLVE_NAME_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        try:
            principal = directory.resolve_username(username)
        except PrincipalNotFound:
            return 404, {"result": "error", "message": "This domain account is unavailable for sign-in."}
        except DirectoryUnavailable:
            return 503, {"result": "error", "message": "Domain authorization is temporarily unavailable."}
        if not principal.group_sids.intersection(allowed_group_sids):
            # Do not return identity details for users outside the configured sign-in population.
            return 404, {"result": "error", "message": "This domain account is unavailable for sign-in."}
        try:
            policy = login_policy.resolve(machine_id, principal.group_sids) if login_policy else {
                "method": METHOD_TPM, "source": "domain-default"
            }
        except PolicyError:
            return 503, {"result": "error", "message": "The workstation sign-in policy is unavailable."}
        return 200, {
            "result": "resolved",
            "credential_method": policy["method"],
            "policy_source": policy["source"],
            "principal": {
                "sid": principal.sid,
                "principal_id": principal.principal_id,
                "principal_type": "domain",
                "authority": principal.authority,
                "username": principal.username,
            },
        }

    return RawBodyRoute(handle)


def login_start_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                      directory: "ActiveDirectory", allowed_group_sids: frozenset[str],
                      challenges: "ChallengeStore", server_host: str,
                      server_fingerprint: str | Callable[[], str], login_policy=None,
                      certificate_template: str | None = None,
                      ad_logon_keys: "AdLogonKeyRegistry | None" = None):
    """Create a QR link only after the machine, SID, and AD group are verified."""
    from .directory import DirectoryUnavailable, PrincipalNotFound
    from .directory import validate_group_sid_allowlist
    from .login_policy import METHOD_EPHEMERAL_CERT, METHOD_TPM, METHOD_WINDOWS, PolicyError
    from .protocol import validate_certificate_template

    allowed_group_sids = validate_group_sid_allowlist(allowed_group_sids)
    try:
        certificate_template = validate_certificate_template(certificate_template)
    except ValueError as exc:
        raise ValueError("Invalid configured AD CS certificate template") from exc
    if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", server_host):
        raise ValueError("Invalid AD service host")
    fingerprint_provider = server_fingerprint if callable(server_fingerprint) else lambda: server_fingerprint

    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        body_fields = set(body)
        if (set(auth_headers) != expected or body_fields not in (
                {"sid", "context"}, {"sid", "context", "certificate_request_sha256"},
                {"sid", "context", "piv_signing"})):
            return 400, {"result": "error", "message": "Invalid sign-in request."}
        if not isinstance(body.get("sid"), str) or body.get("context") not in ("interactive", "unlock", "ssh"):
            return 400, {"result": "error", "message": "Invalid sign-in request."}
        piv_signing = body_fields == {"sid", "context", "piv_signing"} and body.get("piv_signing") is True
        if body_fields == {"sid", "context", "piv_signing"} and not piv_signing:
            return 400, {"result": "error", "message": "Invalid PIV sign-in request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], LOGIN_START_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        machine_name = registry.machine_name(machine_id)
        if not machine_name:
            return 401, {"result": "error", "message": "Machine authentication failed."}
        fingerprint = fingerprint_provider()
        if not isinstance(fingerprint, str) or not re.fullmatch(r"[a-f0-9]{64}", fingerprint):
            return 503, {"result": "error", "message": "The approval certificate is not ready."}
        try:
            principal = directory.resolve_user_sid(body["sid"])
        except PrincipalNotFound:
            return 404, {"result": "error", "message": "Domain user was not found or is disabled."}
        except DirectoryUnavailable:
            return 503, {"result": "error", "message": "Domain authorization is temporarily unavailable."}
        if not principal.group_sids.intersection(allowed_group_sids):
            return 403, {"result": "error", "message": "This account is not authorized on this computer."}
        try:
            policy = login_policy.resolve(machine_id, principal.group_sids) if login_policy else {
                "method": METHOD_TPM, "source": "domain-default"
            }
        except PolicyError:
            return 503, {"result": "error", "message": "The workstation sign-in policy is unavailable."}
        if policy["method"] == METHOD_WINDOWS:
            return 403, {"result": "disabled", "message": "Thessley phone sign-in is disabled for this account on this workstation."}
        if piv_signing and (body["context"] != "interactive" or ad_logon_keys is None
                            or policy["method"] != METHOD_TPM):
            return 503, {"result": "unsupported", "message": "The phone-key signing service is unavailable."}
        if piv_signing and not ad_logon_keys.has_active_key(principal.principal_id):
            return 403, {"result": "unavailable", "message": "This AD account has no active phone logon key for PIV sign-in."}
        certificate_pilot = policy["method"] == METHOD_EPHEMERAL_CERT and not piv_signing
        if certificate_pilot:
            if certificate_template is None:
                return 503, {"result": "unsupported", "message": "The certificate sign-in template is not configured."}
            digest = body.get("certificate_request_sha256")
            if (body["context"] != "interactive" or not isinstance(digest, str)
                    or not re.fullmatch(r"[a-f0-9]{64}", digest)):
                return 400, {"result": "error", "message": "The certificate sign-in request is invalid."}
        elif "certificate_request_sha256" in body:
            return 400, {"result": "error", "message": "This sign-in method does not accept a certificate request."}
        elif policy["method"] != METHOD_TPM:
            return 503, {"result": "unsupported", "message": "The selected Thessley sign-in method is not available yet."}
        try:
            challenge_args = dict(
                machine_id=machine_id,
                sid=principal.sid,
                username=principal.username,
                authority=principal.authority,
                context=body["context"],
                # Give a person enough time to unlock the phone, scan, and
                # approve. The challenge remains one-use and machine-bound.
                lifetime_seconds=180,
            )
            if certificate_pilot:
                challenge_args.update({
                    "certificate_request_sha256": body["certificate_request_sha256"],
                    "certificate_template": certificate_template,
                })
            if piv_signing:
                challenge_args["piv_signing"] = True
            challenge = challenges.create(**challenge_args)
        except (RuntimeError, TypeError, ValueError):
            return 503, {"result": "error", "message": "Could not create a sign-in request."}
        link_values = {
            "h": server_host,
            "p": "47810",
            "fp": fingerprint,
            "id": challenge["request_id"],
            "n": challenge["nonce"],
            "m": machine_id,
            "hn": machine_name,
            "u": principal.username,
            "pv": "3" if certificate_pilot else "2",
            "sid": principal.principal_id,
            "scope": "domain",
            "auth": principal.authority,
            "ctx": body["context"],
            "api": "ad",
        }
        if certificate_pilot:
            link_values.update({
                "csr": challenge["certificate_request_sha256"],
                "tmpl": challenge["certificate_template"],
                "exp": str(int(challenge["expires_at"])),
            })
        if piv_signing:
            link_values["piv"] = "1"
        link = "thessleypam://login?" + urlencode(link_values)
        return 201, {"result": "created", "credential_method": policy["method"],
                     "policy_source": policy["source"], "request": challenge, "app_link": link}

    return RawBodyRoute(handle)


def phone_response_route(challenges: "ChallengeStore"):
    """Accept one signed approval or a nonce-bound refusal from Android."""
    def handle(_client_ip: str, body: dict, _raw_body: bytes, auth_headers: dict[str, str]):
        if auth_headers or set(body) != {"request_id", "credential_id", "action", "timestamp", "signature", "nonce"}:
            return 400, {"result": "error", "message": "Invalid phone response."}
        timestamp = body.get("timestamp")
        if isinstance(timestamp, bool) or not isinstance(timestamp, int):
            return 400, {"result": "error", "message": "Invalid phone response."}
        accepted = challenges.respond(
            request_id=body.get("request_id"),
            credential_id=body.get("credential_id"),
            action=body.get("action"),
            timestamp=timestamp,
            signature_b64=body.get("signature"),
            nonce=body.get("nonce"),
        )
        if not accepted:
            return 409, {"result": "error", "message": "The response was invalid, expired, or already used."}
        return 200, {"result": "ok"}

    return RawBodyRoute(handle)


def login_result_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                       challenges: "ChallengeStore"):
    """Deliver one result only to the machine that created the request."""
    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        if set(auth_headers) != expected or set(body) != {"request_id"} or not isinstance(body.get("request_id"), str):
            return 400, {"result": "error", "message": "Invalid result request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], LOGIN_RESULT_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        result = challenges.consume_result(machine_id=machine_id, request_id=body["request_id"])
        if result is None:
            return 404, {"result": "error", "message": "Sign-in request was not found."}
        return 200, result

    return RawBodyRoute(handle)


def certificate_csr_submit_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                                 challenges: "ChallengeStore"):
    """Accept one verified CSR from the machine after its phone approval."""
    from .certificate_requests import CertificateRequestError

    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        if (set(auth_headers) != expected or set(body) != {"request_id", "csr_der_b64"}
                or not isinstance(body.get("request_id"), str)
                or not re.fullmatch(r"[A-Za-z0-9_-]{8,128}", body["request_id"])
                or not isinstance(body.get("csr_der_b64"), str)
                or not 172 <= len(body["csr_der_b64"]) <= 43692):
            return 400, {"result": "error", "message": "Invalid certificate request upload."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], CERTIFICATE_CSR_SUBMIT_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        try:
            encoded = body["csr_der_b64"].encode("ascii")
            der = base64.b64decode(encoded, validate=True)
            if base64.b64encode(der) != encoded:
                raise ValueError("noncanonical base64")
        except (UnicodeEncodeError, ValueError, binascii.Error):
            return 400, {"result": "error", "message": "Invalid certificate request encoding."}
        try:
            verified = challenges.accept_certificate_request(
                machine_id=machine_id, request_id=body["request_id"], der=der,
            )
        except CertificateRequestError:
            return 400, {"result": "error", "message": "The CSR does not match the approved request profile."}
        if verified is None:
            return 409, {"result": "error", "message": "The approved request is expired, consumed, or unavailable."}
        return 200, {
            "result": "csr_verified",
            "request_id": body["request_id"],
            "certificate_request_sha256": verified["sha256"],
            "public_key_spki_sha256": verified["public_key_spki_sha256"],
            "certificate_template": verified["certificate_template"],
            "issuer_status": "not_configured",
        }

    return RawBodyRoute(handle)


def certificate_result_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                             challenges: "ChallengeStore"):
    """Deliver the validated public certificate to its originating machine."""
    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        request_id = body.get("request_id")
        if (set(auth_headers) != expected or set(body) != {"request_id"}
                or not isinstance(request_id, str)
                or not re.fullmatch(r"[A-Za-z0-9_-]{8,128}", request_id)):
            return 400, {"result": "error", "message": "Invalid certificate result request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], CERTIFICATE_RESULT_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        issued = challenges.get_issued_certificate(machine_id=machine_id, request_id=request_id)
        if issued is None:
            return 404, {"result": "error", "message": "No validated certificate is ready for this request."}
        return 200, {
            "result": "certificate_ready",
            "request_id": request_id,
            "certificate_der_b64": base64.b64encode(issued["certificate_der"]).decode("ascii"),
            "certificate_sha256": issued["certificate_sha256"],
        }

    return RawBodyRoute(handle)


def phone_enrollment_start_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                                 directory: "ActiveDirectory", allowed_group_sids: frozenset[str],
                                 phones: "PhoneRegistry", server_host: str,
                                 server_fingerprint: str | Callable[[], str]):
    """Start first-phone enrollment for an AD-authorized domain SID."""
    from .directory import DirectoryUnavailable, PrincipalNotFound, validate_group_sid_allowlist

    allowed_group_sids = validate_group_sid_allowlist(allowed_group_sids)
    if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", server_host):
        raise ValueError("Invalid AD service host")
    fingerprint_provider = server_fingerprint if callable(server_fingerprint) else lambda: server_fingerprint

    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        if set(auth_headers) != expected or set(body) != {"sid"} or not isinstance(body.get("sid"), str):
            return 400, {"result": "error", "message": "Invalid phone enrollment request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], PHONE_ENROLL_START_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        machine_name = registry.machine_name(machine_id)
        fingerprint = fingerprint_provider()
        if not machine_name or not isinstance(fingerprint, str) or not re.fullmatch(r"[a-f0-9]{64}", fingerprint):
            return 503, {"result": "error", "message": "The AD service is not ready for enrollment."}
        try:
            principal = directory.resolve_user_sid(body["sid"])
        except PrincipalNotFound:
            return 404, {"result": "error", "message": "Domain user was not found or is disabled."}
        except DirectoryUnavailable:
            return 503, {"result": "error", "message": "Domain authorization is temporarily unavailable."}
        if not principal.group_sids.intersection(allowed_group_sids):
            return 403, {"result": "error", "message": "This account is not authorized to enroll a phone."}
        enrollment = phones.create_enrollment(
            machine_id=machine_id, sid=principal.sid, username=principal.username, authority=principal.authority,
        )
        if enrollment is None:
            return 503, {"result": "error", "message": "Could not create a phone enrollment request."}
        link = "thessleypam://enroll?" + urlencode({
            "h": server_host, "p": "47810", "fp": fingerprint, "id": enrollment["request_id"],
            "n": enrollment["nonce"], "m": machine_id, "hn": machine_name, "u": principal.username,
            "pv": "2", "sid": enrollment["principal_id"], "scope": "domain",
            "auth": principal.authority, "ctx": "enrollment", "api": "ad",
        })
        return 201, {"result": "created", "request": enrollment, "app_link": link}

    return RawBodyRoute(handle)


def phone_enrollment_response_route(phones: "PhoneRegistry"):
    """Verify the new Android key and wait for its pairing code to be confirmed on Windows."""
    def handle(_client_ip: str, body: dict, _raw_body: bytes, auth_headers: dict[str, str]):
        expected = {"request_id", "public_key", "algorithm", "label", "timestamp", "proof_signature", "attestation_chain"}
        if (auth_headers or set(body) != expected
                or not isinstance(body.get("request_id"), str)
                or not re.fullmatch(r"[A-Za-z0-9_-]{8,128}", body["request_id"])):
            return 400, {"result": "error", "message": "Invalid phone enrollment response."}
        chain = body.get("attestation_chain")
        if (body.get("algorithm") != "ES256" or not isinstance(chain, list) or len(chain) > 10
                or any(not isinstance(cert, str) or len(cert) > 16384 for cert in chain)):
            return 400, {"result": "error", "message": "Invalid phone enrollment response."}
        timestamp = body.get("timestamp")
        if isinstance(timestamp, bool) or not isinstance(timestamp, int):
            return 400, {"result": "error", "message": "Invalid phone enrollment response."}
        if not phones.submit_enrollment(
            request_id=body.get("request_id"), public_key_spki_b64=body.get("public_key"),
            label=body.get("label"), timestamp=timestamp, signature_b64=body.get("proof_signature"),
            attestation_chain=chain,
        ):
            return 409, {"result": "error", "message": "Phone proof was invalid, expired, or already used."}
        result = phones.wait_enrollment(body["request_id"], timeout=110)
        if result and result.get("status") == "denied":
            return 403, {"result": "denied", "message": "Phone enrollment was cancelled on the Windows computer."}
        if not result or result.get("status") != "confirmed":
            return 409, {"result": "error", "message": "Pairing was not confirmed on the Windows computer."}
        return 200, {"result": "ok", "credential_id": result["credential_id"],
                     "username": result["username"],
                     "attestation_status": result.get("attestation_status", "unverified"),
                     "attestation_reason": result.get("attestation_reason", "")}

    return RawBodyRoute(handle, response_wait=115)


def phone_enrollment_status_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                                  phones: "PhoneRegistry"):
    """Expose only the pairing state to the machine that began that enrollment."""
    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        if (set(auth_headers) != expected or set(body) != {"request_id"}
                or not isinstance(body.get("request_id"), str)
                or not re.fullmatch(r"[A-Za-z0-9_-]{8,128}", body["request_id"])):
            return 400, {"result": "error", "message": "Invalid enrollment status request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], PHONE_ENROLL_STATUS_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        state = phones.enrollment_status(machine_id=machine_id, request_id=body["request_id"])
        if state is None:
            return 404, {"result": "error", "message": "Phone enrollment was not found."}
        return 200, state

    return RawBodyRoute(handle)


def phone_enrollment_confirm_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                                   phones: "PhoneRegistry"):
    """Activate a staged phone key only after the Windows screen's pairing code matches."""
    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        if (set(auth_headers) != expected or set(body) != {"request_id", "pairing_code"}
                or not isinstance(body.get("request_id"), str)
                or not re.fullmatch(r"[A-Za-z0-9_-]{8,128}", body["request_id"])):
            return 400, {"result": "error", "message": "Invalid enrollment confirmation."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], PHONE_ENROLL_CONFIRM_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        if not phones.confirm_enrollment(
            machine_id=machine_id, request_id=body.get("request_id"), pairing_code=body.get("pairing_code"),
        ):
            return 409, {"result": "error", "message": "The pairing code did not match or the request expired."}
        return 200, {"result": "confirmed"}

    return RawBodyRoute(handle)


def phone_enrollment_cancel_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                                  phones: "PhoneRegistry"):
    """Cancel a pending enrollment from its originating authenticated machine."""
    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {
            "x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"
        }
        if (set(auth_headers) != expected or set(body) != {"request_id"}
                or not isinstance(body.get("request_id"), str)
                or not re.fullmatch(r"[A-Za-z0-9_-]{8,128}", body["request_id"])):
            return 400, {"result": "error", "message": "Invalid enrollment cancellation."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(
            machine_id, auth_headers["x-thessley-timestamp"], auth_headers["x-thessley-nonce"],
            auth_headers["x-thessley-signature"], PHONE_ENROLL_CANCEL_PATH, raw_body, registry, replay_guard,
        ):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        if not phones.cancel_enrollment(machine_id=machine_id, request_id=body["request_id"]):
            return 409, {"result": "error", "message": "Phone enrollment is no longer pending."}
        return 200, {"result": "cancelled"}

    return RawBodyRoute(handle)


def ad_logon_key_enroll_route(phones: "PhoneRegistry", logon_keys: "AdLogonKeyRegistry"):
    """Register a separate phone-held AD key using an existing central phone key."""
    from .phone_registry import CENTRAL_AD_MACHINE_ID

    fields = {
        "request_id", "principal_id", "credential_id", "public_key_spki_b64", "label", "nonce",
        "timestamp", "approval_signature_b64", "proof_signature_b64", "attestation_chain", "pairing_code",
    }

    def handle(_client_ip: str, body: dict, _raw_body: bytes, auth_headers: dict[str, str]):
        if auth_headers or set(body) != fields:
            return 400, {"result": "error", "message": "Invalid AD logon-key enrollment."}
        if (not isinstance(body.get("principal_id"), str)
                or not isinstance(body.get("credential_id"), str)
                or not isinstance(body.get("public_key_spki_b64"), str)
                or not isinstance(body.get("label"), str)
                or not isinstance(body.get("request_id"), str)
                or not isinstance(body.get("nonce"), str)
                or isinstance(body.get("timestamp"), bool)
                or not isinstance(body.get("timestamp"), int)
                or not isinstance(body.get("approval_signature_b64"), str)
                or not isinstance(body.get("proof_signature_b64"), str)
                or not isinstance(body.get("pairing_code"), str)):
            return 400, {"result": "error", "message": "Invalid AD logon-key enrollment."}
        approval_key = phones.public_key_for(
            body["credential_id"], CENTRAL_AD_MACHINE_ID, body["principal_id"],
        )
        if approval_key is None:
            return 403, {"result": "error", "message": "An active phone key for this AD account is required."}
        registered = logon_keys.register(
            request_id=body["request_id"], principal_id=body["principal_id"],
            credential_id=body["credential_id"], approval_public_key_spki_b64=approval_key,
            public_key_spki_b64=body["public_key_spki_b64"], label=body["label"],
            nonce=body["nonce"], timestamp=body["timestamp"],
            approval_signature_b64=body["approval_signature_b64"],
            proof_signature_b64=body["proof_signature_b64"],
            attestation_chain=body["attestation_chain"],
            pairing_code=body["pairing_code"],
        )
        if registered is None:
            logging.getLogger("thessley.ad.api").warning(
                "ad_logon_key_enrollment_rejected principal_id=%s credential_id=%s request_id=%s",
                body["principal_id"], body["credential_id"], body["request_id"],
            )
            return 409, {"result": "error", "message": "The key proof was invalid, duplicated, or expired."}
        logging.getLogger("thessley.ad.api").info(
            "ad_logon_key_staged principal_id=%s key_id=%s attestation=%s already_recorded=%s",
            body["principal_id"], registered["key_id"], registered["attestation_status"],
            registered["already_recorded"],
        )
        status = registered["attestation_status"]
        if status == "verified_tee":
            message = "Key recorded; Android attestation verified TEE protection. Windows sign-in still needs its separate provider integration."
        elif status == "verified_strongbox":
            message = "Key recorded; Android attestation verified StrongBox protection. Windows sign-in still needs its separate provider integration."
        elif status == "verified_software":
            message = "Warning: Android attestation reports software-only key protection. It can be used, but has less protection if the phone is compromised."
        else:
            message = "Warning: hardware protection could not be verified. The key can be used, but treat it as software-backed."
        return 202, {"result": "pending_confirmation", **registered,
                     "message": "Compare the code on this phone with the AD admin page. The key is not active until confirmed."}

    return RawBodyRoute(handle)


def ad_logon_key_status_route(logon_keys: "AdLogonKeyRegistry"):
    """Return minimal completion status to the phone holding the QR request ID."""
    def handle(_client_ip: str, body: dict, _raw_body: bytes, auth_headers: dict[str, str]):
        if auth_headers or set(body) != {"request_id"} or not isinstance(body.get("request_id"), str):
            return 400, {"result": "error", "message": "Invalid AD key status request."}
        state = logon_keys.phone_status(body["request_id"])
        if state is None:
            return 404, {"result": "error", "message": "AD key request was not found."}
        return 200, {"result": state["status"], "attestation_status": state["attestation_status"],
                     "key_id": state["key_id"] if state["status"] == "confirmed" else ""}
    return RawBodyRoute(handle)


def piv_sign_start_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                         signatures: "PivSignatureStore"):
    """Queue a digest only for the requesting machine's approved PIV login."""
    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {"x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"}
        if (set(auth_headers) != expected or set(body) != {"request_id", "ad_logon_key_sha256", "digest_b64"}
                or not isinstance(body.get("request_id"), str)
                or not isinstance(body.get("ad_logon_key_sha256"), str)
                or not _HEX_SHA256.fullmatch(body["ad_logon_key_sha256"])
                or not isinstance(body.get("digest_b64"), str)
                or not _B64_PIV_INPUT.fullmatch(body["digest_b64"])):
            return 400, {"result": "error", "message": "Invalid PIV sign request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(machine_id, auth_headers["x-thessley-timestamp"],
                                      auth_headers["x-thessley-nonce"], auth_headers["x-thessley-signature"],
                                      PIV_SIGN_START_PATH, raw_body, registry, replay_guard):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        try:
            encoded = body["digest_b64"].encode("ascii")
            digest = base64.b64decode(encoded, validate=True)
            if (len(digest) not in (32, 35, 51, 67, 83)
                    or base64.b64encode(digest) != encoded):
                raise ValueError("invalid digest")
        except (UnicodeEncodeError, ValueError, binascii.Error):
            return 400, {"result": "error", "message": "Invalid PIV digest."}
        created = signatures.create_for_machine(
            machine_id=machine_id, request_id=body["request_id"],
            ad_logon_key_sha256=body["ad_logon_key_sha256"], digest=digest,
        )
        if created is None:
            return 409, {"result": "error", "message": "No matching active AD PIV sign-in is available."}
        return 201, {"result": "queued", **created}
    return RawBodyRoute(handle)


def piv_sign_result_route(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                          signatures: "PivSignatureStore"):
    """Return a signature only to the originating, machine-authenticated caller."""
    def handle(_client_ip: str, body: dict, raw_body: bytes, auth_headers: dict[str, str]):
        expected = {"x-thessley-machine-id", "x-thessley-timestamp", "x-thessley-nonce", "x-thessley-signature"}
        if (set(auth_headers) != expected or set(body) != {"request_id", "sign_request_id"}
                or not all(isinstance(body.get(name), str) for name in ("request_id", "sign_request_id"))):
            return 400, {"result": "error", "message": "Invalid PIV result request."}
        machine_id = auth_headers["x-thessley-machine-id"]
        if not _authenticated_machine(machine_id, auth_headers["x-thessley-timestamp"],
                                      auth_headers["x-thessley-nonce"], auth_headers["x-thessley-signature"],
                                      PIV_SIGN_RESULT_PATH, raw_body, registry, replay_guard):
            return 401, {"result": "error", "message": "Machine authentication failed."}
        result = signatures.result_for_machine(
            machine_id=machine_id, request_id=body["request_id"], sign_request_id=body["sign_request_id"],
        )
        if result is None:
            return 404, {"result": "error", "message": "PIV sign request was not found."}
        return 200, result
    return RawBodyRoute(handle)


def piv_sign_phone_pending_route(signatures: "PivSignatureStore"):
    def handle(_client_ip: str, body: dict, _raw_body: bytes, auth_headers: dict[str, str]):
        fields = {"request_id", "credential_id", "ad_logon_key_sha256"}
        if (auth_headers or set(body) != fields
                or not all(isinstance(body.get(name), str) for name in fields)):
            return 400, {"result": "error", "message": "Invalid phone PIV request."}
        result = signatures.for_phone(
            request_id=body["request_id"], credential_id=body["credential_id"],
            ad_logon_key_sha256=body["ad_logon_key_sha256"],
        )
        if result is None:
            return 403, {"result": "error", "message": "No matching active phone key is enrolled for this sign-in."}
        return 200, result
    return RawBodyRoute(handle)


def piv_sign_phone_response_route(signatures: "PivSignatureStore"):
    def handle(_client_ip: str, body: dict, _raw_body: bytes, auth_headers: dict[str, str]):
        fields = {"request_id", "sign_request_id", "credential_id", "ad_logon_key_sha256", "signature_b64"}
        if (auth_headers or set(body) != fields
                or not all(isinstance(body.get(name), str) for name in fields)):
            return 400, {"result": "error", "message": "Invalid phone PIV response."}
        accepted = signatures.complete_from_phone(
            request_id=body["request_id"], sign_request_id=body["sign_request_id"],
            credential_id=body["credential_id"], ad_logon_key_sha256=body["ad_logon_key_sha256"],
            signature_b64=body["signature_b64"],
        )
        if not accepted:
            return 409, {"result": "error", "message": "The PIV request expired or the phone signature did not match."}
        return 200, {"result": "signed"}
    return RawBodyRoute(handle)


def create_routes(registry: "MachineRegistry", replay_guard: "ReplayGuard",
                  directory: "ActiveDirectory", allowed_group_sids: frozenset[str],
                  challenges: "ChallengeStore", server_host: str,
                  server_fingerprint: str | Callable[[], str], phones: "PhoneRegistry",
                  login_policy=None, certificate_template: str | None = None,
                  ad_logon_keys: "AdLogonKeyRegistry | None" = None,
                  piv_signatures: "PivSignatureStore | None" = None) -> dict:
    """Build routes without binding them to a particular HTTPS listener."""
    return {
        MACHINE_ENROLL_PATH: machine_enrollment_route(registry),
        MACHINE_AUTH_PATH: machine_authentication_route(registry, replay_guard),
        DIRECTORY_USERS_PATH: directory_users_route(registry, replay_guard, directory, allowed_group_sids),
        PHONE_KEYS_PATH: phone_keys_route(registry, replay_guard, phones),
        PHONE_KEY_REVOKE_PATH: phone_key_revoke_route(registry, replay_guard, phones),
        PRINCIPAL_RESOLVE_PATH: principal_resolve_route(
            registry, replay_guard, directory, allowed_group_sids, login_policy
        ),
        PRINCIPAL_RESOLVE_NAME_PATH: principal_resolve_name_route(
            registry, replay_guard, directory, allowed_group_sids, login_policy
        ),
        LOGIN_START_PATH: login_start_route(
            registry, replay_guard, directory, allowed_group_sids, challenges, server_host, server_fingerprint,
            login_policy, certificate_template, ad_logon_keys,
        ),
        PHONE_RESPONSE_PATH: phone_response_route(challenges),
        LOGIN_RESULT_PATH: login_result_route(registry, replay_guard, challenges),
        CERTIFICATE_CSR_SUBMIT_PATH: certificate_csr_submit_route(registry, replay_guard, challenges),
        CERTIFICATE_RESULT_PATH: certificate_result_route(registry, replay_guard, challenges),
        PHONE_ENROLL_START_PATH: phone_enrollment_start_route(
            registry, replay_guard, directory, allowed_group_sids, phones, server_host, server_fingerprint
        ),
        PHONE_ENROLL_RESPONSE_PATH: phone_enrollment_response_route(phones),
        PHONE_ENROLL_STATUS_PATH: phone_enrollment_status_route(registry, replay_guard, phones),
        PHONE_ENROLL_CONFIRM_PATH: phone_enrollment_confirm_route(registry, replay_guard, phones),
        PHONE_ENROLL_CANCEL_PATH: phone_enrollment_cancel_route(registry, replay_guard, phones),
        **({AD_LOGON_KEY_ENROLL_PATH: ad_logon_key_enroll_route(phones, ad_logon_keys),
            AD_LOGON_KEY_STATUS_PATH: ad_logon_key_status_route(ad_logon_keys)}
           if ad_logon_keys is not None else {}),
        **({PIV_SIGN_START_PATH: piv_sign_start_route(registry, replay_guard, piv_signatures),
            PIV_SIGN_RESULT_PATH: piv_sign_result_route(registry, replay_guard, piv_signatures),
            PIV_SIGN_PHONE_PENDING_PATH: piv_sign_phone_pending_route(piv_signatures),
            PIV_SIGN_PHONE_RESPONSE_PATH: piv_sign_phone_response_route(piv_signatures)}
           if piv_signatures is not None else {}),
    }


def create_ad_enrollment_routes(phones: "PhoneRegistry", logon_keys: "AdLogonKeyRegistry") -> dict[str, RawBodyRoute]:
    """Only Android AD-key registration and status routes on the isolated TLS listener."""
    return {
        AD_LOGON_KEY_ENROLL_PATH: ad_logon_key_enroll_route(phones, logon_keys),
        AD_LOGON_KEY_STATUS_PATH: ad_logon_key_status_route(logon_keys),
    }
