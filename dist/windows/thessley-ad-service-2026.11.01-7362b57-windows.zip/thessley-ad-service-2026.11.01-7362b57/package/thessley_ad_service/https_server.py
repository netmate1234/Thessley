"""Small TLS HTTP transport for the standalone AD API.

This adapter is intentionally independent of the Linux Thessley PAM listener so
the same route logic can be hosted by an isolated Windows lab service later.
"""

from __future__ import annotations

import json
import logging
import ssl
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import TYPE_CHECKING
from urllib.parse import urlsplit

if TYPE_CHECKING:
    from .http_api import RawBodyRoute

MAX_BODY_BYTES = 64 * 1024
_MACHINE_AUTH_HEADERS = (
    "x-thessley-machine-id",
    "x-thessley-timestamp",
    "x-thessley-nonce",
    "x-thessley-signature",
)


def _auth_headers(headers) -> dict[str, str]:
    selected: dict[str, str] = {}
    for name in _MACHINE_AUTH_HEADERS:
        values = headers.get_all(name, [])
        if len(values) > 1 or (values and len(values[0]) > 256):
            raise ValueError("Invalid machine authentication headers.")
        if values:
            selected[name] = values[0]
    return selected


def make_server(address: tuple[str, int], certfile: str, keyfile: str,
                routes: dict[str, "RawBodyRoute"], admin_web=None) -> ThreadingHTTPServer:
    """Create a bounded TLS server for the signed JSON API or separate admin UI."""

    class Handler(BaseHTTPRequestHandler):
        def _dispatch_admin(self, method: str, body: bytes):
            try:
                return admin_web.handle(method, self.path, self.headers, body, self.client_address[0])
            except Exception:
                logging.getLogger("thessley.ad.admin").exception("Administrator site request failed")
                return admin_web._response(500, admin_web._page(
                    "Request failed", '<section class="card error">The request could not be completed. Try again.</section>'
                ))

        def _reply(self, status: int, body: dict) -> None:
            raw = json.dumps(body, ensure_ascii=True, separators=(",", ":")).encode("utf-8")
            self.close_connection = True
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'none'")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def _reply_web(self, response) -> None:
            status, headers, raw = response
            self.close_connection = True
            self.send_response(status)
            for name, value in headers:
                self.send_header(name, value)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(raw)

        def do_GET(self) -> None:
            if admin_web is not None:
                response = self._dispatch_admin("GET", b"")
                if response is not None:
                    self._reply_web(response)
                    return
            self._reply(405, {"result": "error", "message": "POST required."})

        def do_POST(self) -> None:
            try:
                path = urlsplit(self.path)
            except ValueError:
                self._reply(400, {"result": "error", "message": "Invalid request path."})
                return
            if admin_web is not None and path.path.startswith("/admin"):
                lengths = self.headers.get_all("Content-Length", [])
                if (len(lengths) != 1 or self.headers.get("Transfer-Encoding") is not None):
                    self._reply(400, {"result": "error", "message": "Invalid request body."})
                    return
                try:
                    length = int(lengths[0])
                except (TypeError, ValueError):
                    length = 0
                if not 1 <= length <= MAX_BODY_BYTES:
                    self._reply(400, {"result": "error", "message": "Invalid request body."})
                    return
                raw = self.rfile.read(length)
                if len(raw) != length:
                    self._reply(400, {"result": "error", "message": "Invalid request body."})
                    return
                response = self._dispatch_admin("POST", raw)
                if response is not None:
                    self._reply_web(response)
                    return
            route = routes.get(path.path) if not path.query and not path.fragment else None
            if route is None:
                self._reply(404, {"result": "error", "message": "Not found."})
                return
            lengths = self.headers.get_all("Content-Length", [])
            if (len(lengths) != 1 or self.headers.get("Transfer-Encoding") is not None
                    or self.headers.get_content_type() != "application/json"):
                self._reply(400, {"result": "error", "message": "Invalid request body."})
                return
            try:
                length = int(lengths[0])
            except (TypeError, ValueError):
                length = 0
            if not 1 <= length <= MAX_BODY_BYTES:
                self._reply(400, {"result": "error", "message": "Invalid request body."})
                return
            try:
                raw = self.rfile.read(length)
                if len(raw) != length:
                    raise ValueError
                body = json.loads(raw)
                if not isinstance(body, dict):
                    raise ValueError
                auth = _auth_headers(self.headers)
            except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
                self._reply(400, {"result": "error", "message": "Invalid request body."})
                return
            try:
                status, reply = route.handler(self.client_address[0], body, raw, auth)
                if (isinstance(status, bool) or not isinstance(status, int)
                        or not 100 <= status <= 599 or not isinstance(reply, dict)):
                    raise ValueError("invalid API response")
            except Exception as exc:
                frames = " > ".join(
                    f"{frame.name}:{frame.lineno}" for frame in traceback.extract_tb(exc.__traceback__)
                )[-512:]
                logging.getLogger("thessley.ad.api").error(
                    "API route handler failed path=%s exception_type=%s frames=%s",
                    path.path, type(exc).__name__, frames,
                )
                status, reply = 500, {"result": "error", "message": "Could not process this request."}
            self._reply(status, reply)

        def log_message(self, _format: str, *_args) -> None:
            return

        def setup(self) -> None:
            super().setup()
            self.connection.settimeout(5)

    class Server(ThreadingHTTPServer):
        daemon_threads = True
        request_queue_size = 32

        def __init__(self, *args, **kwargs):
            self._request_slots = threading.BoundedSemaphore(32)
            super().__init__(*args, **kwargs)

        def process_request(self, request, client_address):
            if not self._request_slots.acquire(blocking=False):
                self.shutdown_request(request)
                return
            try:
                super().process_request(request, client_address)
            except Exception:
                self._request_slots.release()
                raise

        def process_request_thread(self, request, client_address):
            try:
                super().process_request_thread(request, client_address)
            finally:
                self._request_slots.release()

        def handle_error(self, _request, _client_address) -> None:
            return

    httpd = Server(address, Handler)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(certfile=certfile, keyfile=keyfile)
    httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
    return httpd


def serve(server: ThreadingHTTPServer, stop: threading.Event) -> None:
    """Serve until the caller signals stop; always close the listening socket."""
    thread = threading.Thread(target=server.serve_forever, name="thessley-ad-https", daemon=True)
    thread.start()
    try:
        stop.wait()
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
