"""Strict validation helpers for the disabled AD certificate-sign-in pilot."""

from __future__ import annotations

import hashlib
import hmac
import re

from cryptography import x509
from cryptography.exceptions import UnsupportedAlgorithm
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa
from cryptography.x509.oid import ExtensionOID, NameOID

_SHA256 = re.compile(r"^[a-f0-9]{64}$")
_PILOT_SUBJECT = re.compile(r"^Thessley temporary sign-in [a-f0-9]{32}$")
_PHONE_KEY_SUBJECT = "Thessley AD Logon Key"
_MIN_CSR_DER_SIZE = 128
_RSA_SHA256_SIGNATURE_OID = "1.2.840.113549.1.1.11"
_ECDSA_SHA256_SIGNATURE_OID = "1.2.840.10045.4.3.2"


class CertificateRequestError(ValueError):
    """A CSR is malformed or does not match the approved pilot profile."""


def validate_approved_csr(der: bytes, expected_sha256: str) -> dict[str, str | int]:
    """Validate an exact DER PKCS#10 request before a future CA broker uses it.

    This function does not authorize the principal, consume phone approval,
    contact a CA, or issue a certificate. Its constraints match the isolated
    Windows machine-key generator (random CN) and the Android phone-key CSR
    (fixed CN): no requested extensions, and either RSA-3072/SHA-256 for the
    temporary PC-key pilot, RSA-2048/SHA-256 for phone PIV keys, or ECDSA
    P-256/SHA-256 for phone keys. Callers handling a phone request must bind
    its SPKI digest to an active AD logon key for the challenge SID.
    """
    if not isinstance(der, bytes) or not _MIN_CSR_DER_SIZE <= len(der) <= 64 * 1024:
        raise CertificateRequestError("The DER certificate request has an invalid size.")
    if not isinstance(expected_sha256, str) or not _SHA256.fullmatch(expected_sha256):
        raise CertificateRequestError("The approved CSR digest is malformed.")
    digest = hashlib.sha256(der).hexdigest()
    if not hmac.compare_digest(digest, expected_sha256):
        raise CertificateRequestError("The certificate request does not match the approved digest.")
    try:
        request = x509.load_der_x509_csr(der)
        public_key = request.public_key()
        common_names = request.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
        subject_attributes = [attribute for rdn in request.subject.rdns for attribute in rdn]
        rsa_profile = (isinstance(public_key, rsa.RSAPublicKey)
                       and public_key.key_size == 3072
                       and request.signature_algorithm_oid.dotted_string == _RSA_SHA256_SIGNATURE_OID)
        rsa_phone_profile = (isinstance(public_key, rsa.RSAPublicKey)
                             and public_key.key_size == 2048
                             and request.signature_algorithm_oid.dotted_string == _RSA_SHA256_SIGNATURE_OID)
        ec_profile = (isinstance(public_key, ec.EllipticCurvePublicKey)
                      and isinstance(public_key.curve, ec.SECP256R1)
                      and request.signature_algorithm_oid.dotted_string == _ECDSA_SHA256_SIGNATURE_OID)
        subject_valid = (
            len(subject_attributes) == 1 and len(common_names) == 1 and (
                (rsa_profile and _PILOT_SUBJECT.fullmatch(common_names[0].value) is not None)
                or (rsa_phone_profile and common_names[0].value == _PHONE_KEY_SUBJECT)
                or (ec_profile and common_names[0].value == _PHONE_KEY_SUBJECT)
            )
        )
        extensions_valid = len(request.extensions) == 0
        # Windows' machine-key PKCS#10 encoder adds the RFC 5280 Subject Key
        # Identifier request extension. It is derived from the public key and
        # carries no caller-selected identity or usage, so accept that one
        # exact, noncritical extension while continuing to reject all others.
        if len(request.extensions) == 1:
            extension = request.extensions[0]
            extensions_valid = (
                extension.oid == ExtensionOID.SUBJECT_KEY_IDENTIFIER
                and not extension.critical
                and extension.value.digest
                == x509.SubjectKeyIdentifier.from_public_key(public_key).digest
            )
        if (not request.is_signature_valid or not (rsa_profile or rsa_phone_profile or ec_profile)
                or not subject_valid or not extensions_valid):
            raise CertificateRequestError("The CSR does not match an approved RSA-3072, RSA-2048 phone, or EC P-256 profile.")
    except CertificateRequestError:
        raise
    except (ValueError, TypeError, UnsupportedAlgorithm) as exc:
        raise CertificateRequestError("The certificate request is not valid DER PKCS#10.") from exc
    spki = public_key.public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return {
        "sha256": digest,
        "subject": request.subject.rfc4514_string(),
        "public_key_spki_sha256": hashlib.sha256(spki).hexdigest(),
        "public_key_bits": public_key.key_size,
        "public_key_algorithm": (
            f"rsa-{public_key.key_size}" if isinstance(public_key, rsa.RSAPublicKey) else "ec-p256"
        ),
    }
