Thessley Windows SSH + Web GUI

This package installs the Thessley QR approval service for Windows OpenSSH and its HTTPS admin web GUI.
Read docs/SSH.md and docs/WEB.md before installing. Requires Windows 11, administrator PowerShell, and
Python 3.12+ installed for all users under Program Files. The guided installer can optionally configure
the HTTPS admin page, where administrators manage per-account SSH QR requirements, first factors, allowed source networks, and scheduled updates.
The default firewall scope is local networks plus VPN client subnets 10.8.0.0/24 and 10.8.1.0/24 for SSH, phone approvals, and the web page. In the guided installer, Y/Enter accepts these VPN ranges, N skips them, or enter custom CIDRs.
On multi-adapter PCs, the guided installer asks which IPv4 adapter the phone can reach and keeps using that adapter if its DHCP address changes.
Weekly automatic updates run Sunday at 03:00 local time by default and can be switched off in Admin > Settings.
They verify the package hash and reuse the installer's rollback; SSH policy and firewall rules are preserved.
An opt-in development prototype can route one Windows sign-in account through the Thessley Windows Access Drupal module.
See docs/WINDOWS-LOGON-PROTOTYPE.md; it is not enabled unless an administrator creates its per-account key and Drupal binding.
For cloud mode with changing public client IPs, choose the cloud option in the installer (TCP 22/47810, optionally 47820).
Cloud-provider firewall rules are configured separately.
install or update the experimental
Windows QR sign-in tile with its own rollback. Both are opt-in; retain an SSH session and PIN/password
recovery until tested. Other Windows helper app bundles are included in downloads/.
